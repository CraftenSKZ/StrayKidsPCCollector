/***************************************************
 * Image utilities – Skz Photocard Tracker
 ***************************************************/

/**
 * Detect correct base path automatically
 * - Local dev: /
 * - GitHub Pages: /StrayKidsPCCollector/
 */
export const BASE_PATH = location.hostname.includes('github.io')
  ? '/StrayKidsPCCollector/'
  : '/';

/**
 * Resolve photocard image source from item
 */
export function resolveImageSrc(item) {
  if (!item?.id || typeof item.id !== 'string') {
    return `${BASE_PATH}assets/images/ui/placeholder.webp`;
  }

  const albumFolder = item.id.split('-')[0];
  const filename = `${item.id}.webp`;

  return `${BASE_PATH}assets/images/photocards/${item.category || ''}/${albumFolder}/${filename}`;
}

export function applyImageProps(img, item, { eager = false } = {}) {
  img.src = resolveImageSrc(item);
  img.alt = item.name || '';
  img.loading = eager ? 'eager' : 'lazy';
  img.decoding = 'async';
  img.fetchPriority = eager ? 'high' : 'low';

  img.onerror = () => {
    img.onerror = null;
    img.src = `${BASE_PATH}/assets/images/ui/placeholder.webp`;
  };
}